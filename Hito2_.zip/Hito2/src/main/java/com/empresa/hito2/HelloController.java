package com.empresa.hito2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.bson.Document;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.DeleteResult;
import static com.mongodb.client.model.Filters.eq;

public class HelloController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField ageField;

    @FXML
    private TextField dniField;

    @FXML
    private TextField birthDateField;

    @FXML
    private Label statusLabel;

    @FXML
    private TableView<Person> tableView;

    @FXML
    private TableColumn<Person, String> nameColumn;

    @FXML
    private TableColumn<Person, Integer> ageColumn;

    @FXML
    private TableColumn<Person, String> dniColumn;

    @FXML
    private TableColumn<Person, String> birthDateColumn;

    private MongoCollection<Document> collection; // Declaración de la colección

    private ObservableList<Person> personList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        DatabaseConnection.connect("mongodb+srv://davidjesussanchezrobles23:admin@cluster0.qzp7eor.mongodb.net/", "Hito2");
        tableView.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        collection = DatabaseConnection.getDatabase().getCollection("Hito2", Document.class); // Obtener la colección

        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
        dniColumn.setCellValueFactory(new PropertyValueFactory<>("dni"));
        birthDateColumn.setCellValueFactory(new PropertyValueFactory<>("birthDate"));

        tableView.setItems(personList);

        loadRecords();
    }


    @FXML
    protected void createRecord() {
        String name = nameField.getText();
        String ageText = ageField.getText();
        String dni = dniField.getText();
        String birthDate = birthDateField.getText();

        if (name.isEmpty() || ageText.isEmpty() || dni.isEmpty() || birthDate.isEmpty()) {
            statusLabel.setText("Please enter all fields!");
            return;
        }

        try {
            int age = Integer.parseInt(ageText);

            Document doc = new Document("name", name)
                    .append("age", age)
                    .append("dni", dni)
                    .append("birthDate", birthDate);

            // Insertar en la base de datos
            collection.insertOne(doc);

            // Actualizar la tabla
            loadRecords();

            statusLabel.setText("Record created successfully!");
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid age format!");
        } catch (Exception e) {
            statusLabel.setText("Error: " + e.getMessage());
        }
    }

    @FXML
    protected void deleteRecord() {
        String name = nameField.getText();
        String ageText = ageField.getText();

        if (name.isEmpty() || ageText.isEmpty()) {
            statusLabel.setText("Please enter all fields!");
            return;
        }

        try {
            int age = Integer.parseInt(ageText);
            Document query = new Document("name", name).append("age", age);

            // Eliminar de la base de datos
            DeleteResult result = collection.deleteOne(query);

            // Verificar si se eliminó correctamente
            if (result.getDeletedCount() > 0) {
                statusLabel.setText("Record deleted successfully!");
                loadRecords(); // Recargar la tabla
            } else {
                statusLabel.setText("Record not found!");
            }
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid age format!");
        } catch (Exception e) {
            statusLabel.setText("Error: " + e.getMessage());
        }
    }

    @FXML
    protected void updateRecord() {
        String name = nameField.getText();
        String ageText = ageField.getText();
        String dni = dniField.getText();
        String birthDate = birthDateField.getText();

        if (name.isEmpty() || ageText.isEmpty() || dni.isEmpty() || birthDate.isEmpty()) {
            statusLabel.setText("Please enter all fields!");
            return;
        }

        try {
            int age = Integer.parseInt(ageText);
            Document query = new Document("name", name);
            Document update = new Document("$set", new Document("age", age)
                    .append("dni", dni)
                    .append("birthDate", birthDate));

            // Actualizar en la base de datos
            collection.updateOne(query, update);

            // Actualizar la tabla
            loadRecords();

            statusLabel.setText("Record updated successfully!");
        } catch (NumberFormatException e) {
            statusLabel.setText("Invalid age format!");
        } catch (Exception e) {
            statusLabel.setText("Error: " + e.getMessage());
        }
    }

    @FXML
    protected void readRecord() {
        String name = nameField.getText();
        String age = ageField.getText();
        String dni = dniField.getText();
        String birthDate = birthDateField.getText();

        if (name.isEmpty() || age.isEmpty() || dni.isEmpty() || birthDate.isEmpty()) {
            statusLabel.setText("Please enter all fields!");
            return;
        }

        statusLabel.setText("Nombre: " + name + "\nEdad: " + age + "\nDNI: " + dni + "\nFecha de nacimiento: " + birthDate);
    }


    private void loadRecords() {
        personList.clear();
        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                String name = doc.getString("name");
                Object ageObj = doc.get("age");
                int age = 0;
                if (ageObj instanceof Integer) {
                    age = (int) ageObj;
                } else if (ageObj instanceof String) {
                    age = Integer.parseInt((String) ageObj);
                }
                String dni = doc.getString("dni");
                String birthDate = doc.getString("birthDate");
                personList.add(new Person(name, age, dni, birthDate));
            }
        } catch (Exception e) {
            statusLabel.setText("Error loading records: " + e.getMessage());
        }
    }

    public static class Person {
        private final String name;
        private final int age;
        private final String dni;
        private final String birthDate;

        public Person(String name, int age, String dni, String birthDate) {
            this.name = name;
            this.age = age;
            this.dni = dni;
            this.birthDate = birthDate;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public String getDni() {
            return dni;
        }

        public String getBirthDate() {
            return birthDate;
        }
    }
}




